document.writeln("Hello from External java script.");
console.log("Hello from External java script.");