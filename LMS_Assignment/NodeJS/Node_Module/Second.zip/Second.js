const mym = require("./mymodule").myModule;

var num=13;
var prime=mym.isPrime(num);
console.log("prime : "+prime);

var num=5;
var fact=mym.calFact(num);
console.log("Fact : "+fact);


