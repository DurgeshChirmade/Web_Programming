const v=require("./Third")
const arr=v.getPrime([1,2,3,4,5,6,7,8,9,10])
console.log(arr);

const sarr=v.longStr(["bye","AAAA","Durgesh","QWERTYUU"]);
console.log(sarr);

console.log(v.currDate());