function Contact(){
    return document.getElementById('root').innerHTML=`<h1>Contact Us</h1>`;
}