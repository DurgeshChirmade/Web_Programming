function Home(){
    return document.getElementById('root').innerHTML=`<h1>Welcome Home</h1>`;
}