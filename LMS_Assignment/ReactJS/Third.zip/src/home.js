function Home(){
    return <h1>Hello From React First Function</h1>
}

export default Home;